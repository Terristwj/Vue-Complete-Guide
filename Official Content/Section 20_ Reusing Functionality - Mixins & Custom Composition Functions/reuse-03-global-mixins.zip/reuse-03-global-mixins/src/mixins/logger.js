export default {
  mounted() {
    console.log('Mounted!');
  }
};