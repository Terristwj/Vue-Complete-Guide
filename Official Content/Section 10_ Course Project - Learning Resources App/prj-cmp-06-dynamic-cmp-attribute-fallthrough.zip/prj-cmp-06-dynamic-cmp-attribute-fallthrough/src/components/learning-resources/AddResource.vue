<template>
  <h2>Add Resource</h2>
</template>