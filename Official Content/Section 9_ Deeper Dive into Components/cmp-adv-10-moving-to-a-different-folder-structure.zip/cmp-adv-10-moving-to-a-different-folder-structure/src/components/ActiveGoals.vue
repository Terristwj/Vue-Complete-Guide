<template>
  <h2>Active Goals</h2>
</template>