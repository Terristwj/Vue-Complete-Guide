<template>
  <div>
    <h2>Manage Goals</h2>
    <input type="text" />
  </div>
</template>